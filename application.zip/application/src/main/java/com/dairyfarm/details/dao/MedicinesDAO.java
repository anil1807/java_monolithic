package com.dairyfarm.details.dao;

import com.dairyfarm.details.model.Medicines;
import org.springframework.data.jpa.repository.JpaRepository;
public interface MedicinesDAO extends JpaRepository<Medicines,Integer>{

}
